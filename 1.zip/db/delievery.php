<?php
include 'connect.php';
$sql = "SELECT * FROM ".$_POST['city']." WHERE name='".$_POST['restaurant_name']."';";
$restaurant_list = mysqli_query($conn, $sql);
    if(mysqli_num_rows($restaurant_list) > 0){
    while($row = mysqli_fetch_assoc($restaurant_list))
    {
        if($_POST['total'] < $row['delivery_charge_slab'])
        {
            echo $row['delivery_charges'];
        }
        else {
            echo 0;
        }
    }}
?>