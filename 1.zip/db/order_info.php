<?php
include 'connect.php';
date_default_timezone_set("Asia/Kolkata");
$order_id = "FH".$_POST['restaurant_code'].date('Ymd').mt_rand(1000,9999);
$order_date = date('Y-m-d');
$order_time = date('H:i:s');
$restaurant = $_POST["restaurant"];
$restaurant_code = substr($_POST['restaurant'],0,3);
$college = $_POST["college"];
$hostel = $_POST['hostel'];
$user_name = $_POST['username'];
$order_details = $_POST['order_details'];
$menu_total = $_POST['menu_total'];
$delivery_charge = $_POST['delivery_charge'];
$total = $_POST['total'];
$city = $_POST['city'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$support_number = '7477010551';

        $city='jabalpur';
        $restaurant_table = "restaurant_".$city;
      

$query = "SELECT * FROM ".$restaurant_table." WHERE code = '".$restaurant_code."';";
$get_query = mysqli_query($conn, $query);
if(mysqli_num_rows($get_query) > 0){
    while($row = mysqli_fetch_assoc($get_query)){
    $contact = $row['contact'];
  }
}


$sql = "INSERT INTO `website_orders_info` (`order_id`, `order_date`, `order_time`, `restaurant`, `order_status`, `college`, `hostel`, `user_name`, `order_details`, `total_amount_menu`, `restaurant_discount`, `saddacampus_discount`, `GST`, `delivery_charge`, `total`, `share`, `city`, `email`, `mobile`, `delivery_status`) VALUES 
('".$order_id."', '".$order_date."', '".$order_time."', '".$restaurant."', 1, '".$college."', '".$hostel."', '".$user_name."', '".$order_details."', ".$menu_total.", 0, 0, 0, ".$delivery_charge.", ".$total.", 0, '".$city."', '".$email."', ".$contact.", 'test')";


mysqli_query($conn, $sql);




function sendConfirmationSmsToCustomer($city,$customer_name,$customer_mobile,$total,$restaurant,$restaurant_code,$order_id){
      
       $customer_message_raw="Hi ".$customer_name." Thanks for ordering with food haunt.".' ID :'.$order_id." Your payable amount is ".$total.". You will receive your order from ".$restaurant.". For queries SHOUT at foodhaunt18@gmail.com or call us @ +91-7477010551";
      
      $customer_message =urlencode($customer_message_raw);

      $mobicomm_api_url_cs='http://mobicomm.dove-sms.com/mobicomm//submitsms.jsp?user=Saddacam&key=39dfecef19XX&senderid=INFOSM&accusage=1&mobile='.$customer_mobile.'&message='.$customer_message;

      $ch_cs = curl_init($mobicomm_api_url_cs);
      curl_setopt($ch_cs, CURLOPT_RETURNTRANSFER, true);
      // build the multi-curl handle, adding both $ch
      $mh = curl_multi_init();
      curl_multi_add_handle($mh, $ch_cs);
       // execute all queries simultaneously, and continue when all are complete
       $running = null;
       do {
         curl_multi_exec($mh, $running);
       } while ($running);
        // all of our requests are done, we can now access the results
         $response_cs = curl_multi_getcontent($ch_cs);
         //$this->sendCustomerSmsToSaddacampus($customer_message,$customer_mobile);
         return true;

    }

    $delivery_charge = 30;


function sendOrderSmsToRestaurant($city,$customer_name,$customer_mobile,$total,$restaurant,$restaurant_code,$order_details,$order_id,$restaurant_contact,$hostel,$college){
      
      
              $restaurant_message_raw ="ORDER DETAILS : ".ucfirst($customer_name).' '.$customer_mobile.' ADDRESS: '.$hostel.'; LANDMARK '.$college.';'.$order_details.'; DISC: ; COUP: ; DELIVERY CHARGE:'.$delivery_charge.' ; GST: ; TOTAL - '.$total.' FOOD HAUNT '.$restaurant_code."";
       
        
      
      
      $restaurant_message =urlencode($restaurant_message_raw);

      $mobicomm_api_url_cs='http://mobicomm.dove-sms.com/mobicomm//submitsms.jsp?user=Saddacam&key=39dfecef19XX&senderid=INFOSM&accusage=1&mobile='.$restaurant_contact.'&message='.$restaurant_message;

      $ch_cs = curl_init($mobicomm_api_url_cs);
      curl_setopt($ch_cs, CURLOPT_RETURNTRANSFER, true);
      // build the multi-curl handle, adding both $ch
      $mh = curl_multi_init();
      curl_multi_add_handle($mh, $ch_cs);
       // execute all queries simultaneously, and continue when all are complete
       $running = null;
       do {
         curl_multi_exec($mh, $running);
       } while ($running);
        // all of our requests are done, we can now access the results
         $response_cs = curl_multi_getcontent($ch_cs);
         //$this->sendCustomerSmsToSaddacampus($customer_message,$customer_mobile);
         return true;

    }



  

     sendOrderSmsToRestaurant($city,$user_name,$mobile,$total,$restaurant,$restaurant_code,$order_details,$order_id,$contact,$hostel,$college);
     sendConfirmationSmsToCustomer($city,$user_name,$mobile,$total,$restaurant,$restaurant_code,$order_id);
     sendOrderSmsToRestaurant($city,$user_name,$mobile,$total,$restaurant,$restaurant_code,$order_details,$order_id,$support_number,$hostel,$college);






?>
