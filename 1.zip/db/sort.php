<?php
include 'connect.php';
$dbtable = $_POST['restaurant']."_menu";
    $sql = "SELECT * FROM ".$dbtable." WHERE category = '".urldecode($_POST['cuisine'])."';";
    $menu_list = mysqli_query($conn, $sql);
    function clean($string) {
   	$string = str_replace(' ', '', $string); // Replaces all spaces with hyphens.
   	return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
}
                          
    if(mysqli_num_rows($menu_list) > 0){
    while($row = mysqli_fetch_assoc($menu_list))
                          {
                          
                          echo '
                                <div class="food-item">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-12 col-lg-8">
                                            
                                            <div class="rest-descr">
                                                <h6 class="food-clr">'.$row['product_name'].'</h6>
                                                <p><input type="number" value="1" class="quantity" id="'.clean($row['product_name']).'"></p>
                                            </div>
                                            <!-- end:Description -->
                                        </div>
                                        <!-- end:col -->
                                        <div class="col-xs-12 col-sm-12 col-lg-4 pull-right item-cart-info"> <span class="price pull-left"> Rs. '.$row['price'].'</span> 
                                        <input type="hidden" name="food_code" value="'.$row['product_code'].'" />
                                        <input type="hidden" name="food_item" value="'.$row['product_name'].'" />
                                        <input type="hidden" name="food_price" value="'.$row['price'].'" />
                                        <button type="button" class="btn btn-small btn btn-secondary pull-right add-to-cart">&#43;</a> </div>
                                    </div>
                                    <!-- end:row -->
                                </div>
                                <!-- end:Food item -->';}}
                                ?>
    
    <script src="js/menu.js"></script>
                                