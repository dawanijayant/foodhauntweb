<?php echo '
<!--header starts-->
        <header id="header" class="header-scroll top-header headrom">
            <!-- .navbar -->
            	
            	<nav class="navbar navbar-dark">
                <div class="container">
                    <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                    <a class="navbar-brand" href="index.php"> <img class="img-rounded" src="images/logo.png" alt="" width="80"> </a>
                    <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                        <ul class="nav navbar-nav">
                            <li class="nav-item"> <a class="nav-link" href="about.php">About Us<span class="sr-only"></span></a> </li>
                            <li class="nav-item"> <a class="nav-link" href="contact.php">Contact Us<span class="sr-only"></span></a> </li>
							
							<li class="nav-item"> <a class="nav-link" href="https://play.google.com/store/apps/details?id=com.saddacampus.app" target="_blank">Get The App</a> </li>
							
                           </ul>
                    </div>
                </div>
            </nav>
            
            <!-- /.navbar -->
            </header>';
            ?>