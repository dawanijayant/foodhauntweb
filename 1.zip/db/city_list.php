<?php
include 'connect.php';
$sql = 'SELECT * FROM cities WHERE name = "'.$_POST["city"].'";';
$college_list = mysqli_query($conn, $sql);
          
    if(mysqli_num_rows($college_list) > 0){
    while($row = mysqli_fetch_assoc($college_list))
                          { echo "<script>sessionStorage.setItem('support_no', ".$row['support_number'].");</script>";    
                          echo "<option value='".$row['college']."'>".$row['college']."</option>";}}?>