<?php
include 'connect.php';

$sql = "SELECT * FROM cities WHERE name='".$_POST['city']."';";
$hostel_list = mysqli_query($conn, $sql);
echo "<option value='' disabled selected>Select Hostel</option>";

if(mysqli_num_rows($hostel_list) > 0) {
    while($row = mysqli_fetch_assoc($hostel_list)) {
        $myArray = explode('|', $row['hostel']);
        foreach ($myArray as $value) {
            echo "<option value='".$value."'>".$value."</option>";
        }
    }
}

?>
