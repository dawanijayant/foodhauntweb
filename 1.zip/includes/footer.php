<?php echo ' 
<section class="app-section">
            <div class="app-wrap">
                <div class="container">
                    <div class="row text-img-block text-xs-left">
                        <div class="container">
                            <div class="col-xs-12 col-sm-5 right-image text-center">
                                <figure> <img src="images/application.png" alt="Right Image" class="img-fluid"> </figure>
                            </div>
                            <div class="col-xs-12 col-sm-7 left-text">
                                <h3>The Best Food Delivery App</h3>
                                <p>Now you can make food happen pretty much wherever you are thanks to the free easy-to-use Food Delivery.</p>
                                <div class="social-btns">                                  
                                    <a href="https://play.google.com/store/apps/details?id=com.foodHaunt.app&hl=en" target="_blank" class="app-btn android-button clearfix">
                                        <div class="pull-left"><i class="fa fa-android"></i> </div>
                                        <div class="pull-right"> <span class="text">Available on the</span> <span class="text-2">Play store</span> </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- start: FOOTER -->
            <footer class="footer">
                <div class="container">
                    <!-- top footer statrs -->
                    <div class="row top-footer">
                        <div class="col-xs-12 col-sm-3 footer-logo-block color-gray">
                            <a href="index.php"> <img src="images/finalicon.png" alt="Footer logo" width="150"></a></div>
                        <div class="col-xs-12 col-sm-9 about color-gray">
                            <h5>FooD haunt is an Jabalpur online food ordering and delivery platform launched on 1st january 2018.
                             Users can order food from participating restaurants on our website or with a smartphone/tablet application.</h5>
                            
                        </div>
                        
                        
                    </div>
                    <!-- top footer ends -->
					<div class="page-wrapper">
                <div class="container">
                    <ul class="row links">
                        <li class="col-xs-12 col-sm-3"><h5>Connect to Us</h5></li>
                        <li class="col-xs-12 col-sm-3"><a href="" 			
 			 target="_blank"><span><i class="fa fa-linkedin fa-fw"></i></span>LinkedIn</a></li>
                        <li class="col-xs-12 col-sm-3"><a href="https://www.facebook.com/FoodHaunt/" 
 			 target="_blank"><span><i class="fa fa-facebook fa-fw"></i></span>Facebook</a></li>
                        <li class="col-xs-12 col-sm-3"><a href="https://www.instagram.com/jbp_foodhaunt/" 
 			 target="_blank"><span><i class="fa fa-instagram fa-fw"></i></span>Instagram</a></li>
                    </ul>
            </div></div>
                    <!-- bottom footer statrs -->
                <hr><div class="row bottom-footer">
                        <div class="container">
                            <div class="row">
								<div class="col-xs-12 col-sm-3 address color-gray">
                                    <h5>Phone</h5><h5><a href="tel:+917477010551">+91- 74770 10551</a></h5>
                                </div>
                                <div class="col-xs-12 col-sm-4 address color-gray">
                                    <h5>Address</h5>
                                    <p> Shanti nagar , Jabalpur, Madyapradesh, 482002, INDIA.</p>
                                </div>
                                <div class="col-xs-12 col-sm-5 additional-info color-gray">
                                    <h5>Additional informations</h5>
                                    <p>For any query or complain drop us a mail at <a href="mailto:foodhaunt18@gmail.com">foodhaunt18@gmail.com</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- bottom footer ends -->
                </div>
            </footer>
            <!-- end:Footer -->' 
            
?>