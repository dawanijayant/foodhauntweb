<?php echo '
<!--header starts-->
        <header id="header" class="header-scroll top-header headrom">
            <!-- .navbar -->
            	 <div class="navbar w3-bar w3-white w3-card w3-left-align w3-large">
        <a class="nav1 w3-bar-item w3-button w3-hide-medium w3-hide-large  w3-padding-large w3-hover-gray w3-large w3-white" href="javascript:void(0);" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
        <a href="#" class="nav2 w3-bar-item w3-button w3-padding-small w3-white  w3-hover-white"><img  class="logo" src="finalicon.png"><b>food haunt</b></a>
        <a href="#" class=" nav1 w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white"><b>About Us</b></a>
        <a href="#" class="nav1 w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white"><b>Contact Us</b></a>
        <a href="#" class=" nav1 w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white"><b>Get The App</b></a>
      </div>

      <!-- Navbar on small screens -->
      <div id="navDemo" class="w3-bar-block w3-white w3-hide w3-hide-large w3-hide-medium w3-large">
        <a href="#" class="w3-bar-item w3-button w3-padding-large">About Us</a>
        <a href="#" class="w3-bar-item w3-button w3-padding-large">Contact Us</a>
        <a href="#" class="w3-bar-item w3-button w3-padding-large">Get The App</a>
  
      </div>
            </header>';
            ?>