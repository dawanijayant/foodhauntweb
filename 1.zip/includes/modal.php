<?php 
$data = json_decode(stripslashes($_POST['data']));
$total = $_POST['total'];
     
      	if(!empty($data)){
            foreach($data as $d){ echo '
                <div class="food-item white">
                    <div class="row">
                        <div class="col-xs-12 col-sm-6 col-lg-6">                                                       
                            <div class="rest-descr">
                                <h6>'.$d->count.' x '.$d->fullname.'</h6> </div>
                            <!-- end:Description -->
                        </div>
                        <!-- end:col -->
                        <div class="col-xs-12 col-sm-6 col-lg-6">                                                       
                            <div class="rest-descr">
                                <h6>'.$d->count*$d->price.'</h6> </div>
                            <!-- end:Description -->
                        </div>
                        
                    </div>
                    <!-- end:row -->
                </div>
                <!-- end:Food item -->';}
            echo '<div class="food-item white">
            	  <div class="row">
                        <div class="col-xs-12 col-sm-6 col-lg-6">                                                       
                            <div class="rest-descr">
                                <h6><strong>TOTAL</strong></h6> </div>
                            <!-- end:Description -->
                        </div>
                        <!-- end:col -->
                        <div class="col-xs-12 col-sm-6 col-lg-6">                                                       
                            <div class="rest-descr">
                                <h6><strong>'.$total.'</strong></h6> </div>
                            <!-- end:Description -->
                        </div>
                    </div>   
                    </div>
                    <!-- end:row -->';}
          else echo 'Your Cart is Empty!!';
            

?>